# lodash.assigninwith v4.2.0

The [lodash](https://lodash.com/) method `_.assignInWith` exported as a [Node.js](https://nodejs.org/) module.

## Installation

Using npm:
```bash
$ {sudo -H} npm i -g npm
$ npm i --save lodash.assigninwith
```

In Node.js:
```js
var assignInWith = require('lodash.assigninwith');
```

See the [documentation](https://lodash.com/docs#assignInWith) or [package source](https://github.com/lodash/lodash/blob/4.2.0-npm-packages/lodash.assigninwith) for more details.
