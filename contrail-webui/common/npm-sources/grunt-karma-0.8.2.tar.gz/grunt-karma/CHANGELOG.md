# 0.8.2
* Emergency fix: Don't pass anything to karma if no browsers are defined.

# 0.8.1
* Kill background child process on main process exit. (@trabianmatt)
* Fix passing `client.args` through the commandline.
* Actually override the browsers array.
* Set client default args.
* Merge `client.args` from all sources.

# 0.8.0
* Update to `karma@0.12.0`

#0.3.0
* changed name from gruntacular to grunt-karma

#0.2.0
* support config sharing via options property
* basic example/test suite
* slight refactor
* use latest testacular

#0.1.1
* initial version
* docs
