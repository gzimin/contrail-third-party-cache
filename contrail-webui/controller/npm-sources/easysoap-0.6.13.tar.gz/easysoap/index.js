/**
 * [exports description]
 * @type {[type]}
 */
module.exports = require('./lib/easysoap');
